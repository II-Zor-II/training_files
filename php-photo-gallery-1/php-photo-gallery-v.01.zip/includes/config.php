<?php 
//Database Constants
defined("DB_HOST") ? null : define("DB_HOST","localhost");
defined("DB_USER") ? null : define("DB_USER","root"); // change database username here
defined("DB_PASS") ? null : define("DB_PASS",""); 	 // change database password here
defined("DB_NAME") ? null : define("DB_NAME","photo_gallery");

?>
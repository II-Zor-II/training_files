<div id="footer">Copyright <?php echo date("Y", time()); ?> Zor</div>
	</body>
</html>
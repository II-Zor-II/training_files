<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="initial-scale=1.0">
		<title>Photo Gallery</title>
		<link rel="stylesheet" href="../stylesheets/normalize.css" media="screen">
		<link rel="stylesheet" href="../stylesheets/main.css" media="screen">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="author" content="Zor">
	</head>

	<body>
		<h1>Photo Gallery</h1>
		<hr>